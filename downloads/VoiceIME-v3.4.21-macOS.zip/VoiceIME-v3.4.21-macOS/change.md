# VoiceIME v3.4.21

发布时间：2026-08-20

## 更新内容

- chore: release VoiceIME v3.4.21
- fix: polish image watermark editing controls