# VoiceIME v3.4.0

发布时间：2026-05-13

## 更新内容

- Release VoiceIME 3.4.0
- Polish menu bar and voice typing HUD icons
- Add Typeless-style Fn voice typing
- chore: archive live subtitle hud stabilization spec