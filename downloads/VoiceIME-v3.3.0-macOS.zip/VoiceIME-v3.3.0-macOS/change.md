# VoiceIME v3.3.0

发布时间：2026-05-06

## 更新内容

- Bump version to 3.3.0
- Optimize smart voice transform remote lifecycle
- Improve live subtitle HUD and diagnostics
- Add smart voice transform lifecycle optimization spec