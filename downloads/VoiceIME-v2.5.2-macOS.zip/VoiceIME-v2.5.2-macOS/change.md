# VoiceIME v2.5.2

发布时间：2026-04-14

## 更新内容

- fix: repair self-update helper script