# VoiceIME v3.4.10

发布时间：2026-05-19

## 更新内容

- fix: refine Option voice typing settings