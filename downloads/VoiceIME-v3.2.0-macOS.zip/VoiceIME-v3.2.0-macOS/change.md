# VoiceIME v3.2.0

发布时间：2026-05-06

## 更新内容

- feat: add real-time live subtitles