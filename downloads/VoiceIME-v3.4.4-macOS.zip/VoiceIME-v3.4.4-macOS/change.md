# VoiceIME v3.4.4

发布时间：2026-05-18

## 更新内容

- feat: add phonetic master and smart reply QR