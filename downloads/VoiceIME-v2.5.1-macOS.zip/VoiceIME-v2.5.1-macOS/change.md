# VoiceIME v2.5.1

发布时间：2026-04-14

## 更新内容

- fix: add explicit about update feedback