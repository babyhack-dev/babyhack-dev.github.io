# VoiceIME v3.3.5

发布时间：2026-05-07

## 更新内容

- feat: refine live subtitle HUD controls
- feat: add live subtitle session history