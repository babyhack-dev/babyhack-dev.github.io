# VoiceIME v3.1.1

发布时间：2026-05-06

## 更新内容

- chore: release VoiceIME v3.1.1
- fix: allow update manifest redirect