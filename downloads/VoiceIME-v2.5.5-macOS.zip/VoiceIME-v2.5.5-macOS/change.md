# VoiceIME v2.5.5

发布时间：2026-04-16

## 更新内容

- fix: unify runtime lifecycle cancellation
- docs: sync specs for pronunciation player and update flow