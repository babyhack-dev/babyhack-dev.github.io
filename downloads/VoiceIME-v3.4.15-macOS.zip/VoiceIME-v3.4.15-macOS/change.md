# VoiceIME v3.4.15

发布时间：2026-06-02

## 更新内容

- Harden ChatGPT OAuth callback flow