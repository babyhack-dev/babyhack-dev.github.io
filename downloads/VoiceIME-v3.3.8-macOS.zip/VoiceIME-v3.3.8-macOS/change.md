# VoiceIME v3.3.8

发布时间：2026-05-08

## 更新内容

- fix: stabilize qwen live subtitles
- feat: add qwen local asr model
- Improve voice insertion observability