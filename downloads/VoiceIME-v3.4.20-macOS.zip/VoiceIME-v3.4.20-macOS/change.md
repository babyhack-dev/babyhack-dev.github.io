# VoiceIME v3.4.20

发布时间：2026-08-18

## 更新内容

- chore: release VoiceIME v3.4.20
- feat: add native image watermark editor