# VoiceIME v2.5.0

发布时间：2026-04-14

## 更新内容

- feat: polish about localization and self-update flow
- chore: sync specs and archive completed openspec changes
- fix: check demo repo status before syncing release artifacts