# VoiceIME v3.3.2

发布时间：2026-05-07

## 更新内容

- feat: migrate live subtitles to SenseVoice