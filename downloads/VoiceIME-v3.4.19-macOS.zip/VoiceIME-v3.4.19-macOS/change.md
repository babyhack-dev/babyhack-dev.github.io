# VoiceIME v3.4.19

发布时间：2026-08-02

## 更新内容

- chore: release VoiceIME v3.4.19
- fix: reset permissions against the installed app