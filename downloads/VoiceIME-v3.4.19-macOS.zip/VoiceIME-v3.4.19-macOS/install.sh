#!/bin/bash
# VoiceIME 安装脚本
# 从同目录 VoiceIME.dmg 提取 VoiceIME.app 并安装到目标目录

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="VoiceIME"
BUNDLE_ID="com.voiceime.app"
DMG_PATH="$SCRIPT_DIR/${APP_NAME}.dmg"
DEFAULT_INSTALL_DIR="$HOME/Applications"
APP_DEST_DIR="$DEFAULT_INSTALL_DIR"
APP_DEST="$APP_DEST_DIR/${APP_NAME}.app"
AUTO_LAUNCH=1
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

show_help() {
    cat <<EOF
VoiceIME 安装脚本

用法：
  bash build/install.sh           从同目录 ${APP_NAME}.dmg 安装到 ~/Applications
  bash build/install.sh --no-launch
  bash build/install.sh clean     清除 Keychain 与系统权限记录
  bash build/install.sh help      显示帮助
  bash build/install.sh --target /path/to/install

说明：
  - 默认读取与 install.sh 同目录下的 ${APP_NAME}.dmg
  - 安装时会从 DMG 中提取 ${APP_NAME}.app 并复制到目标目录
  - --no-launch 可用于验证安装链路，但不自动启动 App
  - 保留 Keychain 清理函数，但普通安装流程不会自动调用
  - 普通安装流程会重置系统权限，确保授权状态从当前安装包重新确认
  - 普通安装流程只安装 VoiceIME.app，不会自动注册或启用虚拟发音设备
EOF
}

clear_keychain() {
    echo "🧹 清理 VoiceIME Keychain 与本地认证记录..."
    security delete-generic-password -s com.voiceime -a credentials >/dev/null 2>&1 || true
    defaults delete com.voiceime.app chatgptExpiresAt >/dev/null 2>&1 || true
}

reset_tcc_service() {
    local service="$1"
    local output

    if ! output="$(/usr/bin/tccutil reset "$service" "$BUNDLE_ID" 2>&1)"; then
        echo "❌ 无法重置 $service 权限：${output:-未知错误}"
        return 1
    fi

    if [ -n "$output" ]; then
        printf '%s\n' "$output"
    fi
}

reset_permissions() {
    echo "🔑 重置系统权限记录（${BUNDLE_ID}）..."

    local service
    local failed=0
    for service in Accessibility ScreenCapture Microphone; do
        if ! reset_tcc_service "$service"; then
            failed=1
        fi
    done

    if [ "$failed" -ne 0 ]; then
        echo "❌ 系统权限未完整重置，安装已停止。"
        return 1
    fi

    echo "✅ 辅助功能、屏幕录制与麦克风权限记录已重置"
}

run_clean() {
    clear_keychain
    reset_permissions
    echo "✅ 清理完成；ChatGPT OAuth 需重新登录，其他 API Key 配置已保留。"
}

stop_running_copies() {
    if ! pgrep -x "$APP_NAME" >/dev/null 2>&1; then
        return 0
    fi

    echo "🔄 正在关闭所有运行中的 ${APP_NAME} 副本..."
    pkill -x "$APP_NAME" 2>/dev/null || true
    for _ in {1..24}; do
        if ! pgrep -x "$APP_NAME" >/dev/null 2>&1; then
            return 0
        fi
        sleep 0.5
    done

    echo "❌ 仍有 ${APP_NAME} 副本在运行，请全部退出后重试："
    pgrep -fl "$APP_NAME" 2>/dev/null || true
    return 1
}

refresh_launch_services_registration() {
    if [ ! -x "$LSREGISTER" ]; then
        return 0
    fi

    # 挂载镜像和本地 build 目录可能同时包含相同 Bundle ID；先注销这些临时副本，
    # 再只注册最终安装路径，避免 open/LaunchServices 启动错误的 App。
    "$LSREGISTER" -u "$APP_SRC" >/dev/null 2>&1 || true
    if [ -d "$SCRIPT_DIR/${APP_NAME}.app" ] && [ "$SCRIPT_DIR/${APP_NAME}.app" != "$APP_DEST" ]; then
        "$LSREGISTER" -u "$SCRIPT_DIR/${APP_NAME}.app" >/dev/null 2>&1 || true
    fi
    "$LSREGISTER" -f "$APP_DEST" >/dev/null 2>&1 || true
}

verify_launched_path() {
    local expected_executable="$APP_DEST/Contents/MacOS/$APP_NAME"
    local pid
    local command

    for _ in {1..30}; do
        for pid in $(pgrep -x "$APP_NAME" 2>/dev/null || true); do
            command="$(ps -p "$pid" -o command= 2>/dev/null || true)"
            if [ "$command" = "$expected_executable" ]; then
                echo "✅ 已确认运行路径：$expected_executable"
                return 0
            fi
        done
        sleep 0.2
    done

    echo "❌ 未检测到从目标路径启动的 ${APP_NAME}：$expected_executable"
    pgrep -fl "$APP_NAME" 2>/dev/null || true
    return 1
}

while [ $# -gt 0 ]; do
    case "$1" in
        clean)
            run_clean
            exit 0
            ;;
        help|-h|--help)
            show_help
            exit 0
            ;;
        --target)
            if [ $# -lt 2 ]; then
                echo "❌ --target 需要指定目录"
                exit 1
            fi
            APP_DEST_DIR="$2"
            APP_DEST="$APP_DEST_DIR/${APP_NAME}.app"
            shift 2
            ;;
        --no-launch)
            AUTO_LAUNCH=0
            shift
            ;;
        *)
            echo "❌ 未知参数：$1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

echo "==============================="
echo "  VoiceIME 安装程序"
echo "==============================="
echo ""

if [ ! -f "$DMG_PATH" ]; then
    echo "❌ 找不到安装包：$DMG_PATH"
    exit 1
fi

MOUNT_POINT="$(mktemp -d "${TMPDIR:-/tmp}/voiceime-mount.XXXXXX")"
cleanup() {
    local exit_code=$?
    trap - EXIT
    hdiutil detach "$MOUNT_POINT" -quiet >/dev/null 2>&1 || true
    rm -rf "$MOUNT_POINT"
    exit "$exit_code"
}
trap cleanup EXIT

echo "💿 挂载 DMG..."
hdiutil attach "$DMG_PATH" -mountpoint "$MOUNT_POINT" -nobrowse -quiet

APP_SRC="$MOUNT_POINT/${APP_NAME}.app"
if [ ! -d "$APP_SRC" ]; then
    echo "❌ DMG 中未找到 ${APP_NAME}.app"
    exit 1
fi

mkdir -p "$APP_DEST_DIR"

stop_running_copies

if [ -d "$APP_DEST" ]; then
    echo "🗑  移除旧版本..."
    rm -rf "$APP_DEST"
fi

echo "📦 安装到 $APP_DEST ..."
/usr/bin/ditto "$APP_SRC" "$APP_DEST"

echo "🔏 校验安装目录中的原始签名..."
if ! codesign --verify --deep --strict "$APP_DEST"; then
    echo "❌ 安装后的 App 签名无效，已停止启动"
    exit 1
fi

if ! codesign -d --entitlements - "$APP_DEST" 2>&1 | grep -q "com.apple.security.device.audio-input"; then
    echo "❌ 安装后的 App 缺少预期签名权限，已停止启动"
    exit 1
fi

echo "🧼 清理安装包隔离属性..."
xattr -dr com.apple.quarantine "$APP_DEST" >/dev/null 2>&1 || true

refresh_launch_services_registration
reset_permissions

echo ""
echo "✅ 安装完成！"
echo ""
echo "ℹ️  虚拟发声设备不会在安装脚本中自动注册；如需启用，请在应用内打开“智能发声 → 设备注册”。"

if [ "$AUTO_LAUNCH" = "1" ]; then
    echo ""
    echo "🚀 启动 VoiceIME..."
    open -n -F "$APP_DEST"
    verify_launched_path
else
    echo "⏭️  已跳过自动启动（--no-launch）"
fi

echo ""
echo "==============================="
echo "  启动后请完成权限授权："
echo ""
echo "  1. 辅助功能：系统弹窗点「打开系统设置」勾选"
echo ""
echo "  2. 屏幕录制：智能OCR 首次使用时按提示授权"
echo "     授权后建议点击应用内的「热重启 VoiceIME」"
echo ""
echo "  3. 麦克风：首次按录音快捷键时系统弹窗确认"
echo ""
echo "  默认快捷键："
echo "  • 语音打字：Option（单独点按开始，再点按停止并插入；⌃⌘I 仍可按住说话）"
echo "  • 智能回复：⌃⌘U（选中文字后触发）"
echo "  • 智能发声：⌃⌘O（读取当前选中文本并直接朗读）"
echo "  • 智能OCR：⌃⌘P（框选区域后识别文字）"
echo "  • 智能变音：⌃⌘K（按住说话，松开后识别→重构→发声）"
echo "  • 快速启动器：⌃⌘L（打开统一搜索面板）"
echo "==============================="
