# VoiceIME v3.4.8

发布时间：2026-05-18

## 更新内容

- fix: remove Fn long-press shortcut hint