# VoiceIME v3.4.2

发布时间：2026-05-13

## 更新内容

- fix: polish speech HUD lifecycle