# VoiceIME v3.1.4

发布时间：2026-05-06

## 更新内容

- fix: harden microphone capture failures
- feat: stage reference audio edits