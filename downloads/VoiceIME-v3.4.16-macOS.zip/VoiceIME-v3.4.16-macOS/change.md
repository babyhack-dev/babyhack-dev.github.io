# VoiceIME v3.4.16

发布时间：2026-08-02

## 更新内容

- chore: release VoiceIME v3.4.16
- feat: show ChatGPT account and credential details