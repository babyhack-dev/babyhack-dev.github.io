# VoiceIME v3.4.9

发布时间：2026-05-19

## 更新内容

- chore: release VoiceIME 3.4.9