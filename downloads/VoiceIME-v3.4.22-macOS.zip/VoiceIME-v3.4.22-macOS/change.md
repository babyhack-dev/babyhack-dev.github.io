# VoiceIME v3.4.22

发布时间：tag v3.4.22
Tagger: babyhack <babyhack-dev@users.noreply.github.com>

chore: release VoiceIME v3.4.22
2026-10-04

## 更新内容

- fix: support macOS 27 OCR and release v3.4.22