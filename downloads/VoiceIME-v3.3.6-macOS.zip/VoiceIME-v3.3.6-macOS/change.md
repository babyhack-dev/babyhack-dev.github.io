# VoiceIME v3.3.6

发布时间：2026-05-07

## 更新内容

- feat: add app network proxy