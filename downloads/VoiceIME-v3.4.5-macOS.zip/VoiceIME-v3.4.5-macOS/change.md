# VoiceIME v3.4.5

发布时间：2026-05-18

## 更新内容

- fix: refine smart reply QR and prompts