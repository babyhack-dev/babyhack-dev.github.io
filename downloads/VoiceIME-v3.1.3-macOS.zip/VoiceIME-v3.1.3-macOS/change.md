# VoiceIME v3.1.3

发布时间：2026-05-06

## 更新内容

- feat: redesign reference audio editor