# VoiceIME v3.4.18

发布时间：2026-08-02

## 更新内容

- fix: make release tag lookup portable
- chore: release VoiceIME v3.4.18
- feat: refine multi-account authentication UI