# VoiceIME v3.3.9

发布时间：2026-05-08

## 更新内容

- fix: refine live subtitle hud translation display