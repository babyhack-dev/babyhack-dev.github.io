# VoiceIME v3.4.13

发布时间：2026-05-23

## 更新内容

- Improve smart reply stream retry handling