# VoiceIME v2.4.0

发布时间：2026-04-13

## 更新内容

- feat: add voice history audio actions
- Fix smart reply panel ESC behavior and layout