# VoiceIME v2.4.1

发布时间：2026-04-13

## 更新内容

- chore: archive v2.4.0 openspec change