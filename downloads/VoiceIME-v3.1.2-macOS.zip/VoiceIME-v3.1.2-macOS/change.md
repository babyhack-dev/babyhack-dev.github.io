# VoiceIME v3.1.2

发布时间：2026-05-06

## 更新内容

- feat: add reference audio region editor