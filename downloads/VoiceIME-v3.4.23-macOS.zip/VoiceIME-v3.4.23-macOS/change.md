# VoiceIME v3.4.23

发布时间：2026-10-04

## 更新内容

- fix: keep OCR results visible on macOS 27
- fix: use commit date in release metadata