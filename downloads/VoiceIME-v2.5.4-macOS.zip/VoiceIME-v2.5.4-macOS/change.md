# VoiceIME v2.5.4

发布时间：2026-04-14

## 更新内容

- feat: polish pronunciation history player UI
- style: refine pronunciation history waveform