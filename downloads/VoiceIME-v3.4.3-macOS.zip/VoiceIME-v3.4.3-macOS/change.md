# VoiceIME v3.4.3

发布时间：2026-05-18

## 更新内容

- fix: stabilize screenshot OCR lifecycle
- Reduce menu bar icon horizontal padding