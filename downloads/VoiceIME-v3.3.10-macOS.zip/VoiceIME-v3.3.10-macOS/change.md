# VoiceIME v3.3.10

发布时间：2026-05-09

## 更新内容

- fix: stabilize live subtitle hud anchoring