# VoiceIME v3.4.6

发布时间：2026-05-18

## 更新内容

- fix: center quick launcher and add QR action