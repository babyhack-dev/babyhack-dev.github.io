# VoiceIME v3.5.1

发布时间：2026-10-05

## 更新内容

- fix: add optional watermark image compression in v3.5.1
- docs: point downloads to published v3.5.0 release