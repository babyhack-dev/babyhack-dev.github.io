# VoiceIME v3.4.14

发布时间：2026-05-23

## 更新内容

- fix: cache smart pronunciation synthesis