# VoiceIME v3.4.1

发布时间：2026-05-13

## 更新内容

- Release VoiceIME 3.4.1