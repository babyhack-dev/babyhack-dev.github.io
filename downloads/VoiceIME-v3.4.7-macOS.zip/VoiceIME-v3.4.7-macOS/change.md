# VoiceIME v3.4.7

发布时间：2026-05-18

## 更新内容

- fix: reclaim stale audio capture sessions
- docs: archive completed openspec changes