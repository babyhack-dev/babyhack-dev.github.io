# VoiceIME v3.4.17

发布时间：2026-08-02

## 更新内容

- chore: release VoiceIME v3.4.17
- feat: add multi-account ChatGPT credentials