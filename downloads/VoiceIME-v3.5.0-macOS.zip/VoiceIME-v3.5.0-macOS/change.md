# VoiceIME v3.5.0

发布时间：2026-10-04

## 更新内容

- fix: stabilize cancellation and audio lifecycle for v3.5.0