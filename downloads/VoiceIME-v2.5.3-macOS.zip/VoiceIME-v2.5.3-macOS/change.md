# VoiceIME v2.5.3

发布时间：2026-04-14

## 更新内容

- feat: add pronunciation history and rename transcription history
- chore: archive fix-about-check-update-feedback