# VoiceIME v2.4.2

发布时间：2026-04-13

## 更新内容

- chore: bump version to 2.4.2
- fix: improve updater, compact about panel, and automate release site sync