# VoiceIME v3.4.11

发布时间：2026-05-23

## 更新内容

- chore: release VoiceIME v3.4.11