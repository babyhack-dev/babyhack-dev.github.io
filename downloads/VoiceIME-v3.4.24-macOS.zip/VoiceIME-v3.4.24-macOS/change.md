# VoiceIME v3.4.24

发布时间：2026-10-04

## 更新内容

- fix: stabilize OCR bubble attachment on macOS 27